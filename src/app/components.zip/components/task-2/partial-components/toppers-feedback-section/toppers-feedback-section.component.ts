import { Component } from '@angular/core';

@Component({
  selector: 'app-toppers-feedback-section',
  standalone: true,
  imports: [],
  templateUrl: './toppers-feedback-section.component.html',
  styleUrl: './toppers-feedback-section.component.scss'
})
export class ToppersFeedbackSectionComponent {

}
