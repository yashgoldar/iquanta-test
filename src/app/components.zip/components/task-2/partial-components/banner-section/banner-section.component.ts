import { Component } from '@angular/core';

@Component({
  selector: 'app-banner-section',
  standalone: true,
  imports: [],
  templateUrl: './banner-section.component.html',
  styleUrl: './banner-section.component.scss'
})
export class BannerSectionComponent {

}
