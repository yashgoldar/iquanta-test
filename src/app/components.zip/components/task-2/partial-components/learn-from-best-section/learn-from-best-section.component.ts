import { Component } from '@angular/core';

@Component({
  selector: 'app-learn-from-best-section',
  standalone: true,
  imports: [],
  templateUrl: './learn-from-best-section.component.html',
  styleUrl: './learn-from-best-section.component.scss'
})
export class LearnFromBestSectionComponent {

}
