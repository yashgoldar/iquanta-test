import { Component } from '@angular/core';

@Component({
  selector: 'app-featured-courses-section',
  standalone: true,
  imports: [],
  templateUrl: './featured-courses-section.component.html',
  styleUrl: './featured-courses-section.component.scss'
})
export class FeaturedCoursesSectionComponent {

}
