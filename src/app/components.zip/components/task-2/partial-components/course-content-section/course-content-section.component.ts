import { Component } from '@angular/core';

@Component({
  selector: 'app-course-content-section',
  standalone: true,
  imports: [],
  templateUrl: './course-content-section.component.html',
  styleUrl: './course-content-section.component.scss'
})
export class CourseContentSectionComponent {

}
